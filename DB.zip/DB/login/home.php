<?php
// We need to use sessions, so you should always start sessions using the below code.
	session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.php');
	exit();
}
?>

<?php
require_once("../dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM product WHERE product_id='" . $_GET["product_id"] . "'");
			$itemArray = array($productByCode[0]["product_id"]=>array('product_name'=>$productByCode[0]["product_name"], 'product_id'=>$productByCode[0]["product_id"], 'quantity'=>$_POST["quantity"], 'prod_price'=>$productByCode[0]["prod_price"], 'image'=>$productByCode[0]["image"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["product_id"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["product_id"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["product_id"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dirty Boys Accessories&trade;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/jquery-ui.css">
  <link rel="stylesheet" href="../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../css/style.css">

  <link href="../css/shopstyle.css" type="text/css" rel="stylesheet" /> <!--css for shop-->
  
  <link href="style.css" rel="stylesheet" type="text/css">										<!--css for login-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">		<!--css for login-->

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
    <div class="header-top">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-12 text-center">
            <a href="../index.php" class="site-logo">
              <img src="../images/logo.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <a href="#" class="mx-auto d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
        </div>
      </div>
      


      
      <div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
          
          <div class="mx-auto">
            <nav class="site-navigation position-relative text-left" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none pl-0 d-lg-block border-none">
				<center><li>
				<form action="../search.php" method="post">
				<input type="text" id="search" name="search" placeholder="Search..." style="width:60%; padding: 10px 20px;">
				</form>
				</li></center>
                <li><a href="../index.php" class="nav-link text-left">Home</a></li>
                <li><a href="../socks.php" class="nav-link text-left">Socks</a></li>
                <li><a href="../ties.php" class="nav-link text-left">Ties</a></li>
				<li><a href="../watches.php" class="nav-link text-left">Watches</a></li>
				<li><a href="../lighters.php" class="nav-link text-left">Lighters</a></li>
				<li><a href="../cufflinks.php" class="nav-link text-left">Cufflinks</a></li>
				<li><a href="../glasses.php" class="nav-link text-left">Glasses</a></li>
				<li><a href="../sunglasses.php" class="nav-link text-left">Sun Glasses</a></li>
                <li><a href="../about.php" class="nav-link text-left">History</a></li>
				<li><a href="../cart.php" class="nav-link text-left">
				<?php
					if (!empty($_SESSION["cart_item"])) {
						$total_quantity = 0;
						foreach ($_SESSION["cart_item"] as $item){
							$total_quantity += $item["quantity"];
						}
				?>
						<span class="blink_text"><b><u>Basket (<?php echo $total_quantity; ?>)</u></b></span>
				<?php
					}
					else	{
				?>
						<b><u>Basket</u></b>
				<?php
					}
				?>
				</a></li>
				<li class="active">
				<?php
					if (!isset($_SESSION['loggedin'])) {
						header('Location: ../index.php');
						?>
						<a href="#" onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="nav-link text-left"><b><u>Login</u></b></a>
						<?php
						exit();
					} else {
						?>
						<a href="logout.php" style="width:auto;" class="nav-link text-left"><b><u>Logout</u></b></a>
						<?php
					}
				?>
				</li>
              </ul>                                                                                                                                                                                                                                                                                         
            </nav>

          </div>
         
        </div>
      </div>

    </div>
    
    </div>

    
    

    <div class="hero-2" style="background-image: url('../images/hero_2.jpg');">
     <div class="container">
        <div class="row justify-content-center text-center align-items-center">
          <div class="col-md-8">
            <span class="sub-title">Welcome</span>
            <h2><?php echo 'Welcome ' . $_SESSION['name'] . '!'; ?></h2>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section py-5 custom-border-bottom" data-aos="fade">
      <div class="container">
		<div class="row mb-5">
          <div class="col-12 section-title text-center mb-5">
		  
            <h2><u>User Information</u><h2><br>
            <h3><?php echo 'Username: ' . $_SESSION['name']; ?></h3>
			<h3><?php echo 'Firstname: ' . $_SESSION['fname']; ?></h3>
			<h3><?php echo 'Surname: ' . $_SESSION['lname']; ?></h3>
			<h3><?php echo 'Email: ' . $_SESSION['email']; ?></h3>
			<h3><?php echo 'Mobile Number: ' . $_SESSION['number']; ?></h3><br>
			<h2><u>Address</u><h2><br>
			
			<h3><?php if(empty($_SESSION['postcode'])){
				echo 'Not Known';
			} else { ?>
			<?php echo $_SESSION['address']; ?>, <?php echo $_SESSION['county']; ?>
			<?php echo $_SESSION['postcode']; ?>
			<?php echo $_SESSION['country']; ?>
			<?php
			}
			?> </h3><br>
			
			
			<center>
				<table style="width:1000px" border="3px">
					<thead>
					<h2><u>Here are all of your preivous orders:</u></h2>
						<tr>
							<th>Order ID</th>
							<th>Order Total</th>
							<th>Order Date</th>
							<th>Shipping Address</th>
							<th>Order Status</th>
						</tr>
					</thead>
					<tbody>
		
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "db";
					$conn = new mysqli($servername, $username, $password, $dbname);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					
					$id = $_SESSION['userid'];
					$sql = "SELECT * FROM user_order WHERE user_id = $id";
					
					$result = $conn->query($sql);
							
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							?>
								<tr>
									<td><a href="home.php?selected_id=<?php echo $row['order_id']; ?>"><?php echo $row['order_id']; ?></a></td>
									<td><?php echo $row['order_sum']; ?></td>
									<td><?php echo $row['order_date']; ?></td>
									<td><?php echo $row['shippingaddress']; ?></td>
									<td><?php echo $row['order_status']; ?></td>
								</tr>
							<?php
							}
						}
				?>	
				
				</tbody>
			</table>
			</center>
			
			<?php
			if (isset($_GET['selected_id'])) {
				$order = $_GET["selected_id"];
			?>
				<br>
				<center>
				<table style="width:700px" border="3px">
					<thead>
						<tr>
							<th>Order ID</th>
							<th>Product ID</th>
							<th>Product Name</th>
							<th>Quantity</th>
						</tr>
					</thead>
					<tbody>
		
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "db";
					$conn = new mysqli($servername, $username, $password, $dbname);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					
					$sql = "SELECT * FROM purchases WHERE order_id = $order";
					
					$result = $conn->query($sql);
							
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							?>
								<tr>
									<td><?php echo $row['order_id']; ?></td>
									<td><?php echo $row['product_id']; ?></td>
									<td><?php 
									$theid = $row['product_id'];
									$sql2 = "SELECT product_name FROM product WHERE product_id = $theid";
									
									$result2 = $conn->query($sql2);
									
									if ($result2->num_rows > 0) {
										while($row2 = $result2->fetch_assoc()) {
											$name = $row2['product_name'];
										}
									}
									echo $name ?></td>
									<td><?php echo $row['quantity']; ?></td>
								</tr>
							<?php
							}
						}
				?>	
				
				</tbody>
			</table>
			</center>
				<?php
			}
				?>
			
			<br><h2><u>Admin Panel</u><h2><br>
			<?php
				if($_SESSION['admin'] == 1){
			?>
				<h3>Below is a table containing all products currently for sale, you can change stocks as needed.</h3>
			<div id="product-grid">
				<div class="txt-heading"></div>
					<?php
						$product_array = $db_handle->runQuery("SELECT * FROM product ORDER BY product_id ASC");
							if (!empty($product_array)) { 
								foreach($product_array as $key=>$value){
					?>
				<div class="product-item">
					<form method="post" action="../stockupdate.php?product_id=<?php echo $product_array[$key]["product_id"]; ?>">
					<a href = "shop-single.php?product_id=<?php echo $product_array[$key]["product_id"]; ?>">
						<div class="product-tile-footer">
							<div class="product-title"><?php echo $product_array[$key]["product_name"]; ?></div></a>	
							<?php
							$servername = "localhost";
							$username = "root";
							$password = "";
							$dbname = "db";
							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}
							
							$currentid = $product_array[$key]["product_id"];
							$sql = "SELECT s_quantity FROM product_stock WHERE product_id = $currentid";
							$result = $conn->query($sql);
							
							if ($result->num_rows > 0) {
							// output data of each row
							while($row = $result->fetch_assoc()) {
								$totalQ = $row['s_quantity'];
								}
							} else {
								echo "Data Error, Please go back and login again";
							}
							$conn->close();
							?>
							<?php
							if($totalQ < 1){
								?>
								<div class="cart-action"><input type="tel" class="product-quantity" name="quantityupdate" value="<?php echo $totalQ; ?>" size="2" pattern="[0-9]{1,}" oninvalid="setCustomValidity('Numbers Only')" onchange="try{setCustomValidity('')}catch(e){}" /><input type="submit" style="color:red;" value="Update Stock" class="btnAddAction" /></div>
								<?php
							} else {
								?>
								<div class="cart-action"><input type="tel" class="product-quantity" name="quantityupdate" value="<?php echo $totalQ; ?>" size="2" pattern="[0-9]{1,}" oninvalid="setCustomValidity('Numbers Only')" onchange="try{setCustomValidity('')}catch(e){}" /><input type="submit" value="Update Stock" class="btnAddAction" /></div>
								<?php
							}
							?>
						</div>
					</form>
				</div>
				<?php
					}
				}
				?>
			</div>	
          </div>
        </div>
		
		<div class="row mb-5">
          <div class="col-12 section-title text-center mb-5">
			<h2>The Company's Purchase Data:</h2>
			<center>
				<table style="width:800px" border="3px">
					<thead>
						<tr>
							<th>Purchase ID</th>
							<th>Order ID</th>
							<th>Product ID</th>
							<th>Product Name</th>
							<th>Quantity</th>
						</tr>
					</thead>
					<tbody>
		
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "db";
					$conn = new mysqli($servername, $username, $password, $dbname);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					
					$sql = "SELECT * FROM purchases";
					
					$result = $conn->query($sql);
							
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							?>
								<tr>
									<td><?php echo $row['purchase_id']; ?></td>
									<td><?php echo $row['order_id']; ?></td>
									<td><?php echo $row['product_id']; ?></td>
									<td><?php 
									$theid = $row['product_id'];
									$sql2 = "SELECT product_name FROM product WHERE product_id = $theid";
									
									$result2 = $conn->query($sql2);
									
									if ($result2->num_rows > 0) {
										while($row2 = $result2->fetch_assoc()) {
											$name = $row2['product_name'];
										}
									}
									echo $name ?></td>
									<td><?php echo $row['quantity']; ?></td>
								</tr>
							<?php
							}
						} else {
							//echo "Data Error, Please go back and login again";
						}
				?>	
				
				</tbody>
			</table>
			</center>
			
			<br>
			<h2>The Company's Total User Order Data:</h2>
			<center>
				<table style="width:800px" border="3px">
					<thead>
						<tr>
							<th>Order ID</th>
							<th>User ID</th>
							<th>Order Total</th>
							<th>Order Date</th>
							<th>Shipping Address</th>
							<th>Order Status</th>
						</tr>
					</thead>
					<tbody>
		
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "db";
					$conn = new mysqli($servername, $username, $password, $dbname);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					
					$sql = "SELECT * FROM user_order";
					
					$result = $conn->query($sql);
							
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							?>
								<tr>
									<td><?php echo $row['order_id']; ?></td>
									<td><?php echo $row['user_id']; ?></td>
									<td><?php echo $row['order_sum']; ?></td>
									<td><?php echo $row['order_date']; ?></td>
									<td><?php echo $row['shippingaddress']; ?></td>
									<td><?php echo $row['order_status']; ?></td>
								</tr>
							<?php
							}
						} else {
							//echo "Data Error, Please go back and login again";
						}
				?>	
				
				</tbody>
			</table>
			</center>
		  </div>
		</div>
		
		<div class="row mb-5">
          <div class="col-12 section-title text-center mb-5">
		  
			<h2>Contact Requests:</h2>
			
			<center>
				<table style="width:1000px" border="3px">
					<thead>
						<tr>
							<th>Contact ID</th>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Email</th>
							<th>Telephone Number</th>
							<th>Message</th>
							<th>Date of Message</th>
						</tr>
					</thead>
					<tbody>
		
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "db";
					$conn = new mysqli($servername, $username, $password, $dbname);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					
					$sql = "SELECT * FROM contact";
					
					$result = $conn->query($sql);
							
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							?>
								<tr>
									<td><?php echo $row['contact_id']; ?></td>
									<td><?php echo $row['firstname']; ?></td>
									<td><?php echo $row['surname']; ?></td>
									<td><?php echo $row['email']; ?></td>
									<td><?php echo $row['telNumber']; ?></td>
									<td><?php echo $row['Message']; ?></td>
									<td><?php echo $row['DateofMessage']; ?></td>
								</tr>
							<?php
							}
						} else {
							echo "Data Error, Please go back and login again";
						}
				?>	
				
				</tbody>
			</table>
			</center>
			
			<?php
				} else {
			?>
					<h3>You are not an admin</h3>
			<?php
				}
			?>
		  
		  </div>
		</div>
		
      </div>
    </div>
  
    <div class="footer">
      <div class="container">
        
        <div class="row">
          <div class="col-12 text-center">
            <div class="social-icons">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-youtube"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    Copyright &copy; 2020 DIRTY BOYS GROUP
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../js/jquery-3.3.1.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/jquery.countdown.min.js"></script>
  <script src="../js/bootstrap-datepicker.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.fancybox.min.js"></script>
  <script src="../js/jquery.sticky.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../js/main.js"></script>

</body>

</html>