<?php
session_start();
// Change this to your connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'db';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}
// Now we check if the data from the login form was submitted, isset() will check if the data exists.
if ( !isset($_POST['username'], $_POST['password']) ) {
	// Could not get the data that should have been sent.
	die ('Please fill both the username and password field!');
}

// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
if ($stmt = $con->prepare('SELECT user_id, password FROM user_registry WHERE user_name = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
	$stmt->bind_param('s', $_POST['username']);
	$stmt->execute();
	// Store the result so we can check if the account exists in the database.
	$stmt->store_result();
if ($stmt->num_rows > 0) {
	$stmt->bind_result($id, $password);
	$stmt->fetch();
	// Account exists, now we verify the password.
	// Note: remember to use password_hash in your registration file to store the hashed passwords.
	if (password_verify($_POST['password'], $password)) {
		// Verification success! User has loggedin!
		// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server.
		session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['name'] = $_POST['username'];
		$_SESSION['id'] = $id;
		//echo 'Welcome ' . $_SESSION['name'] . '!';
	} else {
		echo 'Incorrect password!';
	}
} else {
	echo 'Incorrect username!';
}
	$stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dirty Boys Accessories&trade;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/jquery-ui.css">
  <link rel="stylesheet" href="../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../css/style.css">

  <link href="../css/shopstyle.css" type="text/css" rel="stylesheet" /> <!--css for shop-->
  
  <link href="style.css" rel="stylesheet" type="text/css">										<!--css for login-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">		<!--css for login-->

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
    <div class="header-top">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-12 text-center">
            <a href="../index.php" class="site-logo">
              <img src="../images/logo.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <a href="#" class="mx-auto d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
        </div>
      </div>
      


      
      <div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
          
          <div class="mx-auto">
            <nav class="site-navigation position-relative text-left" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none pl-0 d-lg-block border-none">
				<center><li>
				<form action="../search.php" method="post">
				<input type="text" id="search" name="search" placeholder="Search..." style="width:60%; padding: 10px 20px;">
				</form>
				</li></center>
                <li><a href="../index.php" class="nav-link text-left">Home</a></li>
                <li><a href="../socks.php" class="nav-link text-left">Socks</a></li>
                <li><a href="../ties.php" class="nav-link text-left">Ties</a></li>
				<li><a href="../watches.php" class="nav-link text-left">Watches</a></li>
				<li><a href="../lighters.php" class="nav-link text-left">Lighters</a></li>
				<li><a href="../cufflinks.php" class="nav-link text-left">Cufflinks</a></li>
				<li><a href="../glasses.php" class="nav-link text-left">Glasses</a></li>
				<li><a href="../sunglasses.php" class="nav-link text-left">Sun Glasses</a></li>
                <li><a href="../about.php" class="nav-link text-left">History</a></li>
				<li><a href="../cart.php" class="nav-link text-left">
				<?php
					if (!empty($_SESSION["cart_item"])) {
						$total_quantity = 0;
						foreach ($_SESSION["cart_item"] as $item){
							$total_quantity += $item["quantity"];
						}
				?>
						<span class="blink_text"><b><u>Basket (<?php echo $total_quantity; ?>)</u></b></span>
				<?php
					}
					else	{
				?>
						<b><u>Basket</u></b>
				<?php
					}
				?>
				</a></li>
				<li class="active">
				<?php
					if (!isset($_SESSION['loggedin'])) {
						header('Location: ../index.php');
						?>
						<a href="#" onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="nav-link text-left"><b><u>Login</u></b></a>
						<?php
						exit();
					} else {
						?>
						<a href="home.php" style="width:auto;" class="nav-link text-left"><b><u>Account</u></b></a>
						<?php
					}
				?>
				</li>
              </ul>                                                                                                                                                                                                                                                                                         
            </nav>

          </div>
         
        </div>
      </div>

    </div>
    
    </div>

    
	<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "db";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$userid = $_SESSION['id'];
	$sql = "SELECT * FROM user_registry WHERE user_id = $userid";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$_SESSION['userid'] = $row['user_id'];
			$_SESSION['fname'] = $row['name'];
			$_SESSION['lname'] = $row['surname'];
			$_SESSION['email'] = $row['emailaddress'];
			$_SESSION['number'] = $row['mob_number'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['country'] = $row['country'];
			$_SESSION['county'] = $row['county'];
			$_SESSION['postcode'] = $row['postcode'];
			$_SESSION['admin'] = $row['admin'];
		}
	} else {
		echo "Data Error, Please go back and login again";
	}
	$conn->close();
	?>
    

    <div class="hero-2" style="background-image: url('../images/hero_2.jpg');">
     <div class="container">
        <div class="row justify-content-center text-center align-items-center">
          <div class="col-md-8">
            <span class="sub-title">Welcome</span>
            <h2><?php echo 'Welcome ' . $_SESSION['name'] . '!'; ?></h2>
          </div>
        </div>
      </div>
    </div>
	
	<div class="site-section py-5 custom-border-bottom" data-aos="fade">
      <div class="container">
		<div class="row mb-5">
          <div class="col-12 section-title text-center mb-5">
            <h2>Welcome back to Dirty Boy's Accessories<h2><h2>Please click below to go to your account</h2><br>
            <h2><a href="home.php" class="nav-link text-left"><b>Account </b><span class="icon-long-arrow-right"></span></a></h2>
          </div>
        </div>
      </div>
    </div>

	<!--

    <div class="site-section py-5 custom-border-bottom" data-aos="fade">
      <div class="container">
        <nav class="navtop">
			<div>
				<h1>Website Title</h1>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Profile Page</h2>
			<div>
				<p>Your account details are below:</p>
				<table>
					<tr>
						<td>Username:</td>
						<td><?=$_SESSION['name']?></td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><?=$password?></td>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?=$email?></td>
					</tr>
				</table>
			</div>
		</div>
      </div>
    </div>
	
	-->
  
    <div class="footer">
      <div class="container">
        
        <div class="row">
          <div class="col-12 text-center">
            <div class="social-icons">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-youtube"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    Copyright &copy; 2020 DIRTY BOYS GROUP
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../js/jquery-3.3.1.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/jquery.countdown.min.js"></script>
  <script src="../js/bootstrap-datepicker.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.fancybox.min.js"></script>
  <script src="../js/jquery.sticky.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../js/main.js"></script>

</body>

</html>