<?php
session_start();
	$servername = "localhost";
	$database = "db";
	$username = "root";
	$password = "";

	// Create connection
	
	$conn = mysqli_connect($servername, $username, $password, $database);

	// Check connection

	if (!$conn) {	
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$pro_id = $_GET['product_id'];
	$newquantity = $_POST["quantityupdate"];
	
	//echo $pro_id;
	
	$update = "UPDATE product_stock SET s_quantity='$newquantity' WHERE product_id=$pro_id";
	
	if ($conn->query($update) === TRUE) {
		//echo "Record updated successfully";
	} else {
		//"Error updating record: " . $conn->error;
	}
?>

<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM product WHERE product_id='" . $_GET["product_id"] . "'");
			$itemArray = array($productByCode[0]["product_id"]=>array('product_name'=>$productByCode[0]["product_name"], 'product_id'=>$productByCode[0]["product_id"], 'quantity'=>$_POST["quantity"], 'prod_price'=>$productByCode[0]["prod_price"], 'image'=>$productByCode[0]["image"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["product_id"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["product_id"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["product_id"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dirty Boys Accessories&trade;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">
	
  <link href="css/shopstyle.css" type="text/css" rel="stylesheet" /> <!--css for shop-->
  <link href="css/login.css" type="text/css" rel="stylesheet" /> <!--css for login-->


</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
    <div class="header-top">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-12 text-center">
            <a href="index.html" class="site-logo">
              <img src="images/logo.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <a href="#" class="mx-auto d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
        </div>
      </div>
      


      
      <div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
          
          <div class="mx-auto">
            <nav class="site-navigation position-relative text-left" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none pl-0 d-lg-block border-none">
				<center><li>
				<form action="search.php" method="post">
				<input type="text" id="search" name="search" placeholder="Search..." style="width:60%; padding: 10px 20px;">
				</form>
				</li></center>
                <li class="active"><a href="index.php" class="nav-link text-left">Home</a></li>
                <li><a href="socks.php" class="nav-link text-left">Socks</a></li>
                <li><a href="ties.php" class="nav-link text-left">Ties</a></li>
				<li><a href="watches.php" class="nav-link text-left">Watches</a></li>
				<li><a href="lighters.php" class="nav-link text-left">Lighters</a></li>
				<li><a href="cufflinks.php" class="nav-link text-left">Cufflinks</a></li>
				<li><a href="glasses.php" class="nav-link text-left">Glasses</a></li>
				<li><a href="sunglasses.php" class="nav-link text-left">Sun Glasses</a></li>
                <li><a href="about.php" class="nav-link text-left">History</a></li>
				<li><a href="cart.php" class="nav-link text-left">
				<?php
					if (!empty($_SESSION["cart_item"])) {
						$total_quantity = 0;
						foreach ($_SESSION["cart_item"] as $item){
							$total_quantity += $item["quantity"];
						}
				?>
						<span class="blink_text"><b><u>Basket (<?php echo $total_quantity; ?>)</u></b></span>
				<?php
					}
					else	{
				?>
						<b><u>Basket</u></b>
				<?php
					}
				?>
				</a></li>
				<li>
				<?php
					if (!isset($_SESSION['loggedin'])) {
						?>
						<a href="#" onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="nav-link text-left"><b><u>Login</u></b></a>
						<?php
					} else {
						?>
						<a href="login/home.php" style="width:auto;" class="nav-link text-left"><b><u>Account</u></b></a>
						<?php
					}
				?>
				</li>
              </ul>                                                                                                                                                                                                                                                                                         
            </nav>

          </div>
         
        </div>
      </div>

    </div>
    
    </div>

    	<!-- HERE IS ALL OF THE LOGIN STUFF -->

	<div id="id01" class="modal">
		<form class="modal-content animate" action="login/authenticate.php" method="post" autocomplete="off">
			<div class="imgcontainer">
				<span onclick="document.getElementById('id01').style.display='none', $_SESSION['loginfailed'] = FALSE" class="close" title="Close">&times;</span>
				<img src="images/login_image.png" alt="Avatar" class="avatar">
			</div>

			<div class="container">
				<label for="username"><b>Username</b></label>
				<input type="text" placeholder="Enter Username" name="username" id="username" required>

				<label for="password"><b>Password</b></label>
				<input type="password" placeholder="Enter Password" name="password" id="password" required>
        
				<button type="submit" value="Login">Login</button>

				<div class="container" style="background-color:#f1f1f1">
					<span class="psw">New Here! <a href="#" onclick="document.getElementById('id02').style.display='block', document.getElementById('id01').style.display='none'" style="width:auto;"><b>Register?</b></a></span>
					<br>
					<br>
				</div>
			</div>
		</form>
	</div>

	<script>
	// Get the modal
		var modal = document.getElementById('id01');

	// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
	
	<!-- HERE IS ALL OF THE REGISTER STUFF -->

	<div id="id02" class="modal">
		<form class="modal-content animate" action="login/register.php" method="post" autocomplete="off">
			<div class="imgcontainer">
				<span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close">&times;</span>
				<img src="images/login_image.png" alt="Avatar" class="avatar">
			</div>

			<div class="container">
				<label for="username"><b>Username</b></label>
				<input type="text" placeholder="Enter Username" name="username" id="username" required>

				<label for="password"><b>Password</b></label>
				<input type="password" placeholder="Enter Password" name="password" id="password" required>
				
				<label for="email"><b>Email</b></label>
				<input type="email" placeholder="Enter Email" name="email" id="email" required>
        
				<button type="submit" value="Register">Register</button>

				<div class="container" style="background-color:#f1f1f1">
					<span class="psw">Wait, you already have an account? <a href="#" onclick="document.getElementById('id01').style.display='block', document.getElementById('id02').style.display='none'" style="width:auto;"><b>Login</b></a></span>
					<br>
					<br>
				</div>
			</div>
		</form>
	</div>

	<script>
	// Get the modal
		var modal = document.getElementById('id02');

	// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
	
	<!-- WEBSITE STRUCTURE AGAIN -->
  
	<br>

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <span class="icon-check_circle display-3 text-success"></span>
            <h2 class="display-3 text-black font-heading-serif">Stock Updated!</h2>
            <p class="lead mb-5">You have successfully updated the stock!</p>
            <p><a href="login/home.php" class="btn btn-md height-auto px-4 py-3 btn-primary">Back to Account</a></p>
          </div>
        </div>
      </div>
    </div>
  

    
    
    <div class="footer">
      <div class="container">
        
        <div class="row">
          <div class="col-12 text-center">
            <div class="social-icons">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-youtube"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    Copyright &copy; 2020 DIRTY BOYS GROUP
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>




  <script src="js/main.js"></script>

</body>

</html>